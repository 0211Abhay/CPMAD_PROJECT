import 'dart:math';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_storage/get_storage.dart';
import 'package:legal_log/common_widgets/show_loader.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';
import 'package:legal_log/features/authentication/model/advocate_model.dart';

class RegistrationController extends GetxController {
  // Firebase Instances
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
var isLoading = false.obs;

  // Form controllers
  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var mobileController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();

  // Observables for state management
  var selectedCountryCode = '+91'.obs; // Default country code
  var obscurePassword = true.obs;
  var obscureConfirmPassword = true.obs;
  var agreeToTerms = false.obs;
  var generatedOtp = 0.obs;

  // Update the selected country code
  void updateCountryCode(CountryCode code) {
    selectedCountryCode.value = code.dialCode!;
  }

  bool agreetoTermss(){
    if (!agreeToTerms.value) {
      Get.snackbar(
        'Error',
        'Please agree to the terms and conditions.',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return false;
    }else{
      return true;
    }

  }
  // Toggle password visibility
  void togglePasswordVisibility() {
    obscurePassword.value = !obscurePassword.value;
  }

  // Toggle confirm password visibility
  void toggleConfirmPasswordVisibility() {
    obscureConfirmPassword.value = !obscureConfirmPassword.value;
  }

  // Toggle terms and conditions checkbox
  void toggleAgreeToTerms() {
    agreeToTerms.value = !agreeToTerms.value;
  }

  // Form validation
  String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Name is required';
    }
    return null;
  }

  String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email is required';
    } else if (!GetUtils.isEmail(value.trim())) {
      return 'Enter a valid email address';
    }
    return null;
  }

  String? validateMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Mobile number is required';
    } else if (!RegExp(r'^\d{10}$').hasMatch(value.trim())) {
      return 'Enter a valid 10-digit mobile number';
    }
    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Password is required';
    } else if (value.trim().length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  String? validateConfirmPassword(String? value) {
    if (value == null || value.trim() != passwordController.text.trim()) {
      return 'Passwords do not match';
    }
    return null;
  }

  // Check if email and phone number are already registered
Future<bool> verifyEmailAndPhone() async {
  try {
    // Concatenate country code with the mobile number
    // String fullPhoneNumber = '${selectedCountryCode.value}${mobileController.text.trim()}';

    // Check if email already exists in Firestore
    QuerySnapshot emailQuery = await _firestore
        .collection('advocate')
        .where('email_address', isEqualTo: emailController.text.trim())
        .get();

    // Check if phone number already exists in Firestore
    // QuerySnapshot phoneQuery = await _firestore
    //     .collection('advocate')
    //     .where('phone_no', isEqualTo: fullPhoneNumber)
    //     .get();

    if (emailQuery.docs.isNotEmpty) {
      Get.snackbar(
        'Error',
        'The email address is already registered.',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return false;
    }

    // if (phoneQuery.docs.isNotEmpty) {
    //   Get.snackbar(
    //     'Error',
    //     'The phone number is already registered.',
    //     backgroundColor: Colors.red,
    //     colorText: Colors.white,
    //   );
    //   return false;
    // }

    return true; // Email and phone are not registered
  } catch (e) {
    Get.snackbar(
      'Error',
      'An error occurred during verification. Please try again later.',
      backgroundColor: Colors.red,
      colorText: Colors.white,
    );
    return false;
  }
}

// Send OTP only if email and phone are verified
Future<void> sendOtpIfVerified() async {
  // Validate email and phone first
  bool isVerified = await verifyEmailAndPhone();

  if (isVerified) {
    // Send OTP if verification succeeds
    await sendVerificationEmail(emailController.text.trim());
    Get.toNamed('/verify_otp'); // Navigate to OTP verification page
  }
}


  // Send OTP to email
  Future<void> sendVerificationEmail(String recipientEmail) async {
    final String senderEmail = 'aryan.langhanoja119561@marwadiuniversity.ac.in';
    final String senderPassword = 'dvvm xula uqrn nolx'; // Your email password
    generatedOtp.value = Random().nextInt(900000) + 100000; // Generate a 6-digit OTP
    print('Generated OTP: ${generatedOtp.value}');

    final smtpServer = gmail(senderEmail, senderPassword);

    final message = Message()
      ..from = Address(senderEmail, 'Legal Log')
      ..recipients.add(recipientEmail)
      ..subject = 'Email Verification'
      ..text = 'Your verification code is ${generatedOtp.value}';

    try {
      final sendReport = await send(message, smtpServer);
      print('Message sent: ' + sendReport.toString());
    } catch (e) {
      print('Message not sent. Error: $e');
    }
  }

void verifyOtp(int userInputOtp) async {
  if (isLoading.value) return; // Prevent multiple taps
  isLoading.value = true;

  // Show loading animation
  showLottieDialog(
    animationPath: 'assets/lottie/Loading.json',
    message: 'Verifying OTP...',
  );

  try {
    await Future.delayed(Duration(seconds: 4)); // Simulate OTP verification delay

    if (userInputOtp == generatedOtp.value) {
      // Show success animation
      Get.back(); // Close the loader before showing success dialog
      showLottieDialog(
        animationPath: 'assets/lottie/hammer.json',
        message: 'OTP Verified Successfully!',
        autoClose: true,
      );
      await registerUser();
      
    } else {
      // Show error animation
      // Get.back(); // Close the loader before showing error dialog
      showLottieDialog(
        animationPath: 'assets/lottie/cross.json',
        message: 'Invalid OTP. Please try again.',
        autoClose: true,
      );

      await Future.delayed(Duration(seconds: 2)); // Allow user to see error dialog
    }
  } catch (e) {
    // Show error dialog
    // Get.back(); // Close the loader before showing error dialog
    showLottieDialog(
      animationPath: 'assets/lottie/cross.json',
      message: 'An error occurred. Please try again later.',
      autoClose: true,
    );

    await Future.delayed(Duration(seconds: 2)); // Allow user to see error dialog
  } finally {
    isLoading.value = false;
    Get.back(); // Close the remaining dialog if any
  }
}


  // Register user after OTP verification
    // Register user after OTP verification
  Future<void> registerUser() async {
    if (!agreeToTerms.value) {
      Get.snackbar(
        'Error',
        'Please agree to the terms and conditions.',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    try {
      // Concatenate country code with the mobile number
      String fullPhoneNumber = '${selectedCountryCode.value}${mobileController.text.trim()}';

      // Register user in Firebase Auth
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      // Prepare advocate data
      Advocate advocate = Advocate(
        advocateId: userCredential.user!.uid,
        emailAddress: emailController.text.trim(),
        name: nameController.text.trim(),
        password: passwordController.text.trim(),
        phoneNo: fullPhoneNumber,
      );

      // Store advocate details in Firestore
      await _firestore.collection('advocate').doc(userCredential.user!.uid).set({
        'advocate_id': advocate.advocateId,
        'email_address': advocate.emailAddress,
        'name': advocate.name,
        'password': advocate.password, // Hash this in production!
        'phone_no': advocate.phoneNo,
      });

      // Save the user data in GetStorage
      final GetStorage storage = GetStorage();
      storage.write('user', {
        'advocate_id': advocate.advocateId,
        'email_address': advocate.emailAddress,
        'name': advocate.name,
        'phone_no': advocate.phoneNo,
      });

      // Show success message
      Get.snackbar(
        'Success',
        'Registration completed successfully!',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );

      // Navigate to the home page
      Get.toNamed('/home_page');
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString(),
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

}